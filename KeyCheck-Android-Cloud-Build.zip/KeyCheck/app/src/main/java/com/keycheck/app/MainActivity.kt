package com.keycheck.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF101310)
private val Panel = Color(0xFF1B211D)
private val Green = Color(0xFF54D68B)
private val Muted = Color(0xFF9BA99F)

data class ConfigEntry(val raw: String, val protocol: String, val label: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KeyCheckScreen() }
    }
}

@Composable
fun KeyCheckScreen() {
    var url by remember { mutableStateOf("https://gitverse.ru/api/repos/FUKIFA/FUFIKA/raw/branch/master/FUKIFAWLL") }
    var configs by remember { mutableStateOf(emptyList<ConfigEntry>()) }
    var message by remember { mutableStateOf("Импортируй файл или загрузи список по URL.") }
    var testing by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("Реальный тест протокола пока не подключён — пинг не измерялся.") }
    val scope = rememberCoroutineScope()

    val context = androidx.compose.ui.platform.LocalContext.current
                        ""
                    }
                    message = "Выбран файл. Для чтения используйте кнопку импорта ниже."
                } catch (e: Exception) { message = "Не удалось открыть файл: ${e.message}" }
            }
        }
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Не удалось прочитать файл")
                    }
                    configs = parseConfigs(text)
                    message = "Загружено конфигураций: ${configs.size}"
                    report = "Реальный тест протокола пока не подключён — пинг не измерялся."
                } catch (e: Exception) { message = "Ошибка импорта: ${e.message}" }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("KeyCheck", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("VLESS · Hysteria2 · Проверка конфигураций", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Всего", configs.size.toString(), Modifier.weight(1f))
                StatCard("Работают", "—", Modifier.weight(1f))
                StatCard("Доступность", "—", Modifier.weight(1f))
            }
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("URL списка") }, modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(
                onClick = {
                    scope.launch {
                        message = "Загружаю список…"
                        try {
                            val body = withContext(Dispatchers.IO) {
                                val conn = URL(url.trim()).openConnection() as HttpURLConnection
                                conn.connectTimeout = 12000
                                conn.readTimeout = 15000
                                conn.requestMethod = "GET"
                                try {
                                    if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                                    conn.inputStream.bufferedReader().use { it.readText() }
                                } finally { conn.disconnect() }
                            }
                            configs = parseConfigs(body)
                            message = "Загружено конфигураций: ${configs.size}"
                            report = "Реальный тест протокола пока не подключён — пинг не измерялся."
                        } catch (e: Exception) {
                            message = "Ошибка загрузки: ${e.message}"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Загрузить по URL") }
            OutlinedButton(onClick = { picker.launch(arrayOf("text/*", "application/octet-stream")) },
                modifier = Modifier.fillMaxWidth()) { Text("Импортировать файл") }
            Button(
                onClick = {
                    testing = true
                    // Deliberately do not label configs as working without a real protocol engine.
                    report = "Проверка не выполнена: движок VLESS/Hysteria2 не подключён. Результаты не выдумываются."
                    testing = false
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (testing) "Проверяю…" else "Проверить все ключи") }
            Text(message, color = Muted, fontSize = 13.sp)
            Text(report, color = Green, fontSize = 13.sp)
            Text("Список (${configs.size})", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
                items(configs) { item ->
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(12.dp)) {
                        Text(item.protocol, color = Green, fontWeight = FontWeight.Bold)
                        Text(item.label, color = Color.White, maxLines = 2, fontSize = 13.sp)
                    }
                }
            }
            Text("Не публикуй экспорт как проверенный, пока движок тестирования не подключён.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(title, color = Muted, fontSize = 12.sp)
        Text(value, color = Green, fontWeight = FontWeight.Bold, fontSize = 22.sp)
    }
}

fun parseConfigs(input: String): List<ConfigEntry> =
    input.lineSequence().map { it.trim() }
        .filter { it.startsWith("vless://", true) || it.startsWith("hysteria2://", true) || it.startsWith("hy2://", true) }
        .distinct()
        .map { line ->
            val protocol = when {
                line.startsWith("vless://", true) -> "VLESS"
                else -> "Hysteria2"
            }
            val label = runCatching {
                val after = line.substringAfter("://")
                after.substringAfter('@').substringBefore('#').substringBefore('?').ifBlank { "Конфигурация без имени" }
            }.getOrDefault("Конфигурация")
            ConfigEntry(line, protocol, label)
        }.toList()
