# KeyCheck (Android) — исходный проект

Тёмный интерфейс с зелёными статусами, импорт локального файла и загрузка списка по URL GitVerse.

## Текущее состояние

Это **исходный прототип интерфейса**, а не готовый APK. В нём реализованы:
- импорт текстового файла через Android file picker;
- загрузка текстового списка по URL;
- распознавание строк `vless://`, `hysteria2://` и `hy2://`;
- подсчёт распознанных конфигураций и отображение списка.

**Реальный тест VLESS/Hysteria2, измерение задержки, подсчёт доступности и экспорт только работающих конфигураций пока не реализованы.** Кнопка проверки намеренно не выдаёт фиктивных результатов.

Для настоящей проверки нужен совместимый сетевой движок (например, интеграция sing-box/libbox или Xray-core) и корректный способ запускать и останавливать тестовые туннели на Android. Простая проверка TCP-порта не является подтверждением работоспособности VLESS, а Hysteria2 использует QUIC/UDP.

## Сборка

1. Открой каталог в Android Studio (JDK 17).
2. Дождись синхронизации Gradle.
3. Выбери `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

Минимальная версия Android: 8.0 (API 26). Сборка здесь не запускалась, APK не приложен.

## Безопасность

Конфигурационные URL часто содержат секреты. Не публикуй скриншоты с полными ссылками и не загружай приватные конфигурации в неизвестные сервисы. URL для загрузки должен быть доверенным HTTPS-адресом.


## Cloud APK build with GitHub Actions

The repository includes `.github/workflows/build-apk.yml`. After the project is committed to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build Android APK**.
3. Tap **Run workflow** (or push a commit to `main`/`master`).
4. Open the completed run and download the `KeyCheck-debug-apk` artifact.
5. Extract the downloaded artifact ZIP to find `app-debug.apk`.

This workflow builds the current prototype only. It does not add the real VLESS/Hysteria2 test engine; the app must not be treated as a working configuration checker yet.
